<?php $title='Presentation av Gallery scriptet'; ?>
<?php $path=__DIR__; include(__DIR__ . '/../mall/header.php'); ?> 



<div id='box7' class="box">
    <h1>Presentation av Gallery scriptet</h1>
    <h4>Ett galleri av bilder.</h4>
    <p>Klicka på de olika bilderna. Perfekt för att visa up er samling eller kollektion eller produkter, eller vadsomhelst. Rekommendation: alla bilder som används bör helst vara i samma storlek!</p>
    <div class="gallery">
        <div class="gallery-current"><img/></div>
        <div class="gallery-all">
  <img src1='../img/1.jpg' width='400' height='300'/>
  <img src1='../img/3.jpg' width='400' height='300'/>
  <img src1='../img/6.jpg' width='400' height='300'/>
  <img src1='../img/9.jpg' width='400' height='300'/>
  <img src1='../img/10.jpg' width='400' height='300'/>
  <img src1='../img/11.jpg' width='400' height='300'/>
  <img src1='../img/13.jpg' width='400' height='300'/>
        </div>
    </div>
</div>


<?php $path=__DIR__; include(__DIR__ . '/../mall/footer.php'); ?> 